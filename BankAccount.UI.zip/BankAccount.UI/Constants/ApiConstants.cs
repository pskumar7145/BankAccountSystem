﻿namespace BankAccountSimulation.UI.Constants
{
    public static class ApiConstants
    {
        public static string BaseApiUrl { get; set; }
    }
}
