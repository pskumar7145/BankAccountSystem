﻿namespace BankAccountSimulation.UI.Helper
{
    public class Helper
    {
        public enum AlertType
        {
            success,
            danger,
            warning,
            info
        }
    }
}
