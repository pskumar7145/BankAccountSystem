﻿namespace BankAccountSimulation.UI.Models
{
    public class DashboardViewModel
    {
        public decimal CurrentBalance { get; set; }
        public decimal TotalDeposits { get; set; }
        public decimal TotalExpenses { get; set; }
    }
}
